package com.StudentManagement.FullStackApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FullStackAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
