package com.StudentManagement.FullStackApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FullStackAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(FullStackAppApplication.class, args);
	}

}
