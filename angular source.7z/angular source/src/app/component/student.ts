export class Student {


    public  id:number;
    public firstname:String ;
    public  lastname:String ;
     public courseName:string;
    
}


