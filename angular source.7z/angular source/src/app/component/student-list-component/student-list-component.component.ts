import { Component, OnInit } from '@angular/core';
import {Student} from "../Student";
import { StudentListproviderService } from 'src/app/service/student-listprovider.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-student-list-component',
  templateUrl: './student-list-component.component.html',
  styleUrls: ['./student-list-component.component.css']
})
export class StudentListComponentComponent implements OnInit {


students:Student[];

  constructor(public service :StudentListproviderService) { }

  ngOnInit(): void {
    this.reset();
    this.getList();
    
  }

  reset(form?:NgForm){
    if(form!=null)
form.resetForm();
this.service.formdata={
id:null,
firstname:'',
lastname:'',
courseName:'',

}


  }

 
  onSubmit(form:NgForm){
    console.log("form submit")
this.insretform(form)

  }

  //insert data 
  insretform(form:NgForm){
 
    if(form.value.id==null){
    
      console.log("insert data")
            console.log("insert"+JSON.stringify(form.value))
            this.service.postData(form.value).subscribe(res=>{

              //this.toastr.success("Record inserted","emp register ")
              this.getList();
              this.reset(form)
            })

      }else{

        console.log("update data")
      
        this.service.updateRecord(form.value).subscribe(res=>{

          this.getList();
          this.reset(form)

        })

        
       
      }
      
      

    } 
  
  // list from api 
    getList(){

  this.service.getStudentList().subscribe(
    data => {
      this.students = data;

    })
 

}


populate(Std:Student){

this.service.formdata=Std;

}

}


