import { TestBed } from '@angular/core/testing';

import { StudentListproviderService } from './student-listprovider.service';

describe('StudentListproviderService', () => {
  let service: StudentListproviderService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(StudentListproviderService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
