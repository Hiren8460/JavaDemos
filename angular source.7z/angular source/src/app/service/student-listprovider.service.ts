import { Injectable } from '@angular/core';
import { Student } from "../component/student";
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { CompileShallowModuleMetadata } from '@angular/compiler';
@Injectable({
  providedIn: 'root'
})
export class StudentListproviderService {

  formdata:Student;
  lists:Student[]; 

  private baseUrl="http://localhost:8086/api/list";

readonly posturl="http://localhost:8086/api/add";
  constructor(public http:HttpClient) { }


  private putBaseUrl="http://localhost:8086/api/edit";


getStudentList():Observable<Student[]>{

  

  return this.http.get<Student[]>(this.baseUrl)
  console.log(this.lists)

}

postData(formdata:Student)
  {
    //console.log("data==json=>"+this.jsonconvert(formdata))

console.log("post called")
return this.http.post(this.posturl,formdata);


  }

  updateRecord(formdata:Student){
  console.log("formdata.id====="+formdata.id)
   
    return this.http.put(this.putBaseUrl+"/"+formdata.id,formdata);
  }

}

