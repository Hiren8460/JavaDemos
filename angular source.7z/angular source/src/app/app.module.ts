import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { StudentListComponentComponent } from './component/student-list-component/student-list-component.component';
import { StudentListproviderService } from "./service/student-listprovider.service";
import { FormsModule } from "@angular/forms";
import { HttpClientModule} from "@angular/common/http";
@NgModule({
  declarations: [
    AppComponent,
    StudentListComponentComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [
    StudentListproviderService,
    

  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
