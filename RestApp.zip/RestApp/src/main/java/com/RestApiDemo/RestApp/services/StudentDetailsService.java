package com.RestApiDemo.RestApp.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.RestApiDemo.RestApp.StudentRepo.StudentServiceRepo;
import com.RestApiDemo.RestApp.entity.Student;
import com.RestApiDemo.RestApp.serviceinterfaces.StudentServiceImpl;

@Service
public class StudentDetailsService  {

	@Autowired
	StudentServiceImpl studentServiceImpl;
	

	public List<Student> getStudents() {
		
		
		return studentServiceImpl.findAll();
	}
	
	
	public void addStudent(Student student) {
		
		studentServiceImpl.save(student);
	}
	
	public List<Student> getStudentByname(String name) {
		
		
		return studentServiceImpl.getStudentByFirstName(name);
	}
	
	public Integer getMark(String startdate,String enddate) {
		
		
		return studentServiceImpl.getSum(startdate, enddate);
	}
	
}
