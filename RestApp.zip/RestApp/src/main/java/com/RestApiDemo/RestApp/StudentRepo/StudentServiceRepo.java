package com.RestApiDemo.RestApp.StudentRepo;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.RestApiDemo.RestApp.entity.Student;

@Repository
public class StudentServiceRepo {
	
	@Autowired
	EntityManager em ;
	public Student getStudentByFirstName(String firstName) {
		
		
		
		
		return null;
	}

}
