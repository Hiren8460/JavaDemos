package com.RestApiDemo.RestApp.serviceinterfaces;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.RestApiDemo.RestApp.entity.Student;

public interface StudentServiceImpl  extends JpaRepository<Student, Integer> {

	@Query("from Student where firstname= :firstname")
	public List<Student> getStudentByFirstName(String firstname);
	
	@Query("SELECT sum(marks) FROM Student where (admission_date between :startdate and :enddate)")
	public Integer getSum(String startdate ,String enddate);
	
}
