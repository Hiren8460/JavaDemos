package com.RestApiDemo.RestApp.controllers;

import java.util.List;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.RestApiDemo.RestApp.entity.Student;
import com.RestApiDemo.RestApp.services.StudentDetailsService;

@RestController
@RequestMapping("/api")
public class StudentController {

	@Autowired
	StudentDetailsService studentDetailsService;
	
	@GetMapping("/getstudent")
	public ResponseEntity<Object> getStudentByName() {
		
		JSONObject response= new JSONObject();
		response.put("StudentList", studentDetailsService.getStudents());
		
		
		
		return new ResponseEntity<Object>(response.toMap(), HttpStatus.OK); 
	}
	@GetMapping("/getstudentbyname/{name}")
	public ResponseEntity<Object> getStudentByName(@PathVariable("name") String name) {
		
		JSONObject response= new JSONObject();
		response.put("StudentList", studentDetailsService.getStudentByname(name));
		
		return new ResponseEntity<Object>(response.toMap(), HttpStatus.OK); 
	}
	
	
	@PostMapping("/addStudent")
	public ResponseEntity<Object> addStudent(@RequestBody Student student) {
		
		JSONObject response= new JSONObject();
		
		try {
		studentDetailsService.addStudent(student);
		
		}catch (Exception e) {
			// TODO: handle exception
			
			response.put("Status_code", 500);
			response.put("mesaage", "Intrenal server error");
			//return "reord not ";
		}
		response.put("Status_code", 200);
		response.put("mesaage", "Record added successfully ");
		
		return new ResponseEntity<Object>(response.toMap(), HttpStatus.OK);
	}
	
	@GetMapping("/getsumofStudentsmarks/{startdate}/{enddate}")
	public ResponseEntity<Object> getSumOfStudentsMarks(@PathVariable("startdate") String startdate,@PathVariable("enddate") String enddate) {
		
		JSONObject response= new JSONObject();
		response.put("sumOfmarks",studentDetailsService.getSumOfMark(startdate,enddate));
		return new ResponseEntity<Object>(response.toMap(), HttpStatus.OK);
	}
	
}
